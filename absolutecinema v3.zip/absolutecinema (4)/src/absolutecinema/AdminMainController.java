package absolutecinema;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;

public class AdminMainController {

    @FXML
    private ComboBox<String> schedule;
    @FXML
    private ComboBox<String> loc;  
    @FXML
    private ComboBox<String> mov;     
    @FXML
    private ComboBox<String> time;     
    @FXML
    private Button seatno;
    
    @FXML
    private Button logoutBtn;   
    
    @FXML
    private Button shortcutbutton;
   
    @FXML
    private Label movieTitle;
    
    @FXML
    private Label durationLabel;
    
    @FXML
    private ImageView image;
    
    @FXML
    public AnchorPane dupli; // Reference to existing pane
    @FXML
    private AnchorPane container; // Where duplicates are added

    private double nextX = 50;

    @FXML
    public void initialize() {
        schedule.getItems().addAll(
            "10:00 AM - Frieren Fantasy XV",
            "01:00 PM - Hatsune Miku: The Black Parade",
            "04:00 PM - No movie",
            "07:00 PM - No movie"
        );
    }

    @FXML
    private void handleBuyTickets1(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/ActualBooking.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading Payment.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @FXML
    public void handleStart(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/AdminActualBooking.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading Payment.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleProceedToPayment(ActionEvent event) {
    
        boolean anyEmpty = false;
        String emptyFields = "";

   
        if (schedule.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Schedule\n";
        }
        if (loc.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Location\n";
        }
        if (mov.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Movie\n";
        }
        if (time.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Time\n";
        }
        //if (seatno.getValue() == null) {
        //    anyEmpty = true;
        //    emptyFields += "Seat\n";
        //}
        if ("Seat".equals(seatno.getText())) { // Check if the button text is "Seat"
            anyEmpty = true;
            emptyFields += "Seat\n"; // Add to the list of empty fields
        }


        if (anyEmpty) {
         
            if (emptyFields.split("\n").length == 5) {
                showAlert("Please fill out all fields before proceeding to payment.", Alert.AlertType.WARNING);
            } else {
                showAlert("Please select the following fields:\n" + emptyFields, Alert.AlertType.WARNING);
            }
            return;
        }

        switchScene("Payment.fxml");

        new Thread(() -> {
            try {
                Thread.sleep(4000);
                Platform.runLater(() -> switchScene("Payment.fxml"));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void switchScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) shortcutbutton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            System.err.println("Error switching scene to " + fxmlFile + ": " + e.getMessage());
        }
    }

    private void showAlert(String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Action Info");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    @FXML
    private void showPopup() throws IOException {
        // Load the pop-up FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SeatNumb.fxml"));
        Parent root = loader.load();

        SeatNumbController popupController = loader.getController(); // Get pop-up controller
        
        // Create and display the pop-up
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL); // Block interaction with main window
        stage.showAndWait(); // Wait for pop-up to close

        // Get the clicked button's text from the pop-up
        String SelectedAttribute = popupController.getSelectedAttribute();
        if (SelectedAttribute != null && !SelectedAttribute.isEmpty()) {
            seatno.setText(SelectedAttribute); // Update the button text
        }
    }
    
   @FXML
    private void handleLogout(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/WelcomeScreen.fxml"));
        Parent root = loader.load();

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

        System.out.println("Successfully logged out and returned to WelcomeScreen.");

    } catch (IOException e) {
        e.printStackTrace();
        showAlert("Failed to load WelcomeScreen: " + e.getMessage(), Alert.AlertType.ERROR);
    }
}





}

