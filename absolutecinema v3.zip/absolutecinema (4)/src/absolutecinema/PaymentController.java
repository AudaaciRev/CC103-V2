package absolutecinema;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Region;
import javafx.scene.Node;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

public class PaymentController implements Initializable {

    private int bookingId;
    private double amount;

    public void setBookingDetails(int bookingId, double amount) {
        this.bookingId = bookingId;
        this.amount = amount;
    }

    @FXML
    private TextField nameF;

    @FXML
    private TextField emailF;

    @FXML
    private ComboBox<String> modPay;

    @FXML
    private Button cancelBtn;

    @FXML
    private Button confirmBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        modPay.getItems().addAll("Credit Card", "Debit Card", "PayPal", "Gcash");
        modPay.setPromptText("Select a payment method");
        modPay.setValue(null);
    }

    
    private boolean isValidGmail(String email) {
        return email.matches("^[A-Za-z0-9._%+-]+@gmail\\.com$");
    }

    @FXML
    private void handleCancel() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Cancel Payment");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to cancel the payment?");
        alert.getDialogPane().getStylesheets().add(getClass().getResource("payment.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("custom-alert");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                nameF.clear();
                emailF.clear();
                modPay.setValue(null);
                redirectToMain();
            }
        });
    }

    
  @FXML
    private void handleConfirm() {
        String name = nameF.getText();
        String email = emailF.getText();
        String payment = modPay.getValue();

       
        if (name.isEmpty() || email.isEmpty() || payment == null || payment.trim().isEmpty()) {
            showPopup("Incomplete Form", "Please fill in all required fields.", Alert.AlertType.WARNING);
            return;
        }

    
        if (!isValidGmail(email)) {
            showPopup("Invalid Email", "Only Gmail accounts (@gmail.com) are accepted.", Alert.AlertType.ERROR);
            return;
        }

        try (Connection conn = getConnection()) {
            if (conn != null) {
                String sql = "INSERT INTO payment_details (booking_id, name, email, amount, mode_of_payment) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, bookingId);
                    stmt.setString(2, name);
                    stmt.setString(3, email);
                    stmt.setDouble(4, amount);
                    stmt.setString(5, payment);

                    int rowsInserted = stmt.executeUpdate();
                    if (rowsInserted > 0) {
                        showPopup("Payment Successful", "Thank you for your payment!\n\nName: " + name + "\nEmail: " + email + "\nPayment Method: " + payment, Alert.AlertType.INFORMATION);

                        
                        PauseTransition delay = new PauseTransition(Duration.seconds(3));
                        delay.setOnFinished(e -> redirectToMain());
                        delay.play();
                    } else {
                        showPopup("Payment Error", "Payment was not processed successfully.", Alert.AlertType.ERROR);
                    }
                }
            }
        } catch (Exception e) {
            showPopup("Payment Error", "An error occurred while processing your payment. Please try again later.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }
  
 
    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/yourdatabase";
        String user = "yourusername";
        String password = "yourpassword";
        return DriverManager.getConnection(url, user, password);
    }

   
    private void redirectToMain() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/Main.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) confirmBtn.getScene().getWindow();  // Get the current stage

            if (stage != null) {
                stage.setScene(new Scene(root));  // Set new scene
                stage.show();
            } else {
                showPopup("Error", "Stage is null. Unable to proceed with redirection.", Alert.AlertType.ERROR);
            }
        } catch (IOException e) {
            showPopup("Error", "Failed to return to the main page.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    private void showPopup(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.getDialogPane().setMinWidth(450);

        alert.showAndWait();
    }
}


