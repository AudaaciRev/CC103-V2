package absolutecinema;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Region;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PaymentController implements Initializable {

    private int bookingId;
    private double amount;

    public void setBookingDetails(int bookingId, double amount) {
        this.bookingId = bookingId;
        this.amount = amount;
    }

    @FXML
    private TextField nameF;

    @FXML
    private TextField emailF;

    @FXML
    private ComboBox<String> modPay;

    @FXML
    private Button cancelBtn;

    @FXML
    private Button confirmBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Add payment options to ComboBox
        modPay.getItems().addAll("Credit Card", "Debit Card", "PayPal", "Gcash", "Your Soul");
        modPay.setPromptText("Select a payment method");
        modPay.setValue(null);
    }

    @FXML
    private void handleCancel() {
        // Confirmation dialog for cancel action
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Cancel Payment");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to cancel the payment?");
        alert.getDialogPane().getStylesheets().add(getClass().getResource("payment.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("custom-alert");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // Clear input fields if confirmed
                nameF.clear();
                emailF.clear();
                modPay.setValue(null);
                try {
                    // Load the new FXML file
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
                    Parent root = loader.load();

                    // Get the current stage and set the new scene
                    Stage stage = (Stage) cancelBtn.getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (Exception e) {
                    System.err.println("Error occurred while loading Main.fxml: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("Cancel action was canceled.");
            }
        });
    }

    @FXML
    private void handleConfirm() {
        // Grab input values
        String name = nameF.getText();
        String email = emailF.getText();
        String payment = modPay.getValue();
        
        if (name.isEmpty() || email.isEmpty() || payment == null || payment.trim().isEmpty()) {
            // Error alert if fields are incomplete
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Incomplete Form");
            alert.setHeaderText(null);
            alert.setContentText("Please fill in all fields.");
            alert.showAndWait();
            return;
        } else {
            try {
                Connection conn = DBConnection.getConnection();
                if (conn != null) {
                    String sql = "INSERT INTO payment_details (booking_id, name, email, amount, mode_of_payment) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, bookingId);
                    stmt.setString(2, name);
                    stmt.setString(3, email);
                    stmt.setDouble(4, amount);
                    stmt.setString(5, payment);

                    int rowsInserted = stmt.executeUpdate();

                    if (rowsInserted > 0) {
                        System.out.println("Payment saved to database sumakses!");

                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Payment Confirmed!");
                        alert.setHeaderText("Thank you for your payment!");
                        alert.setContentText("Name: " + name + "\nEmail: " + email + "\nPayment Method: " + payment);
                        alert.getDialogPane().getStylesheets().add(getClass().getResource("payment.css").toExternalForm());
                        alert.getDialogPane().getStyleClass().add("custom-alert");
                        alert.showAndWait();

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
                        Parent root = loader.load();
                        Stage stage = (Stage) confirmBtn.getScene().getWindow();
                        stage.setScene(new Scene(root));
                        stage.show();
                    }

                    stmt.close();
                    conn.close();
                }
            } catch (Exception e) {
                System.err.println("Error occurred while saving payment: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public void showCustomAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "This is a custom alert box!", ButtonType.OK);
        alert.setTitle("Custom Alert");
        alert.setHeaderText("Custom Header");

        // Set a custom size for the alert
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.getDialogPane().setMinWidth(400); // Adjust the width

        // Add CSS styles (optional)
        alert.getDialogPane().getStylesheets().add(getClass().getResource("custom.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("custom-alert");

        alert.showAndWait();
    }

}
