package absolutecinema;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class AdminActualBookingController implements Initializable {

    // FXML references to your ComboBoxes
    @FXML private ComboBox<String> loc;
    @FXML private ComboBox<String> date;
    @FXML private ComboBox<String> time;
    @FXML private ComboBox<String> cinema;
    @FXML private Button seatno;
    @FXML private Button prodpay;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize location options
        loc.setItems(FXCollections.observableArrayList("Manila", "Cebu", "Davao"));

        // Initialize date options
        date.setItems(FXCollections.observableArrayList("April 12", "April 13", "April 14"));

        // Initialize time options
        time.setItems(FXCollections.observableArrayList("10:00 AM", "1:00 PM", "4:00 PM", "7:00 PM"));

        // Default cinema options (will change based on location)
        cinema.setItems(FXCollections.observableArrayList("Select a location first"));

        // Event listener for location change
        loc.setOnAction(e -> updateCinemas(loc.getValue()));
    }

    // Update cinemas based on selected location
    private void updateCinemas(String location) {
        switch (location) {
            case "Manila":
                cinema.setItems(FXCollections.observableArrayList("SM Manila", "Robinsons Ermita", "Greenbelt"));
                break;
            case "Cebu":
                cinema.setItems(FXCollections.observableArrayList("Ayala Cebu", "SM Cebu", "Robinsons Galleria"));
                break;
            case "Davao":
                cinema.setItems(FXCollections.observableArrayList("SM Davao", "Abreeza", "Gaisano Mall"));
                break;
            default:
                cinema.setItems(FXCollections.observableArrayList("No cinemas found"));
                break;
        }
    }
    
        @FXML
    private void showPopup() throws IOException {
        // Load the pop-up FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SeatNumb.fxml"));
        Parent root = loader.load();

        SeatNumbController popupController = loader.getController(); // Get pop-up controller
        
        // Create and display the pop-up
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL); // Block interaction with main window
        stage.showAndWait(); // Wait for pop-up to close

        // Get the clicked button's text from the pop-up
        String SelectedAttribute = popupController.getSelectedAttribute();
        if (SelectedAttribute != null && !SelectedAttribute.isEmpty()) {
            seatno.setText(SelectedAttribute); // Update the button text
        }
    }
    
    @FXML
    public void handleHome(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/Main.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading Payment.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
     @FXML
    private void handleProceedToPayment(ActionEvent event) {
    
        boolean anyEmpty = false;
        String emptyFields = "";

   
        if (date.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Date\n";
        }
        if (loc.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Location\n";
        }
        if (cinema.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Cinema\n";
        }
        if (time.getValue() == null) {
            anyEmpty = true;
            emptyFields += "Time\n";
        }
        //if (seatno.getValue() == null) {
        //    anyEmpty = true;
        //    emptyFields += "Seat\n";
        //}
        if ("Seat Number".equals(seatno.getText())) { // Check if the button text is "Seat"
            anyEmpty = true;
            emptyFields += "Seat\n"; // Add to the list of empty fields
        }
        
        if (anyEmpty) {
         
            if (emptyFields.split("\n").length == 5) {
                showAlert("Please fill out all fields before proceeding to payment.", Alert.AlertType.WARNING);
            } else {
                showAlert("Please select the following fields:\n" + emptyFields, Alert.AlertType.WARNING);
            }
            return;
        }

        switchScene("Payment.fxml");

        new Thread(() -> {
            try {
                Thread.sleep(4000);
                Platform.runLater(() -> switchScene("Payment.fxml"));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void switchScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) prodpay.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            System.err.println("Error switching scene to " + fxmlFile + ": " + e.getMessage());
        }
    }
    
    private void showAlert(String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Action Info");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
